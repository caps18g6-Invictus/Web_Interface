 <?php
 $user = $_GET['name'];
 $deviceid = $_GET['deviceid'];
 ?>
 
 <html>
 <head>
 <title>SET SCHEDULE</title>
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <style>
 .modal
 {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content
 {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
}

/* The Close Button */
.close 
{
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus 
{
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
 </style>
 <script LANGUAGE="JavaScript">
 function setname()
{
	var u1=document.getElementById('name');
	var d1=document.getElementById('deviceid');
	var u2=document.getElementById('user');
	var d2=document.getElementById('devid');
	u2.value=u1.innerHTML;
	d2.value=d1.innerHTML;
}
 </script>
 </head>
 <body onLoad="setname()">
 <label id="name" hidden ><?php echo $user ?></label>
<label id="deviceid" hidden ><?php echo $deviceid ?></label>
 <iframe width="0" height="0" border="0" name="dummyframe1" id="Iframe1"></iframe>
<h1>SET SCHEDULE</h1>
<h2>Schedule ON</h2>
<form action="http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/schedtest.php?" method="get" target="dummyframe1">
<input type="hidden" name="status" value=1 readonly>
<input type="hidden" name="pass" value=123 readonly>
<input type="hidden" name="trun" value=0 readonly>
<input type="hidden" name="username"  id="user" >
<input type="hidden" name="devid" id="devid">
<input type="datetime-local" name="dates" id="date1">
<input id="Submit1" type="submit" value="Set">
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <p id="model"></p>
  </div>
</div>

<script>
var modal = document.getElementById('myModal');
var btn = document.getElementById("Submit1");
var span = document.getElementsByClassName("close")[0];
var date1 = document.getElementById("date1");
var model = document.getElementById("model");

// When the user clicks the button, open the modal 
btn.onclick = function() 
{
    modal.style.display = "block";
	model.innerHTML="A Schedule was set to SWITCH ON at Time : "+date1.value; 
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() 
{
    modal.style.display = "none";
}
</script>
</form>

<iframe width="0" height="0" border="0" name="dummyframe2" id="Iframe2"></iframe>
<h2>Schedule OFF</h2>
<form action="http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/schedtest.php?" method="get" target="dummyframe2">
<input type="hidden" name="status" value=0 readonly>
<input type="hidden" name="pass" value=123 readonly>
<input type="hidden" name="trun" value=0 readonly>
<input type="hidden" name="username"  id="user" >
<input type="hidden" name="devid" id="devid">
<input type="datetime-local" name="dates" id="date1">
<input id="Submit1" type="submit" value="Set">
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <p id="model"></p>
  </div>
</div>

<script>
var modal = document.getElementById('myModal');
var btn = document.getElementById("Submit2");
var span = document.getElementsByClassName("close")[0];
var date2 = document.getElementById("date2");
var model = document.getElementById("model");

// When the user clicks the button, open the modal 
btn.onclick = function() 
{
    modal.style.display = "block";
	model.innerHTML="A Schedule was set to SWITCH OFF at Time : "+date2.value; 
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() 
{
    modal.style.display = "none";
}
</script>
</form> 
 </body>
 </html>