<h2>RGB</h2>
<p>Choose the Color</p>
<iframe src="http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/rgb.html" name="RGB" height="200" width="100%"></iframe>




<iframe width="0" height="0" border="0" name="dummyframe" id=dummyframe"></iframe>
<form action="http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/test.php?" method="get" target="dummyframe">
<h1>Intensity</h1>
<div class="""slidecontainer">
<input type="hidden" name="cid" value=2 readonly>
<input type="range" min="0" max="1023" value="512" class="slider" id="myRange" name="intensity">
<input type="hidden" name="pass" value=123 readonly>
<input type="hidden" name="trun" value=0 readonly>
  <p>Value: <span id="demo"></span></p>
<script>
    var slider = document.getElementById("myRange");
    var output = document.getElementById("demo");
    output.innerHTML = slider.value;
    slider.oninput = function () 
    {
        output.innerHTML = this.value;
    }
	
</script>
<input id="Set" type="submit" value="Set"  >
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <p id="model"></p>
  </div>
</div>

<script>
var modal = document.getElementById('myModal');
var btn = document.getElementById("Set");
var span = document.getElementsByClassName("close")[0];
var slider1 = document.getElementById("myRange");
var model = document.getElementById("model");

// When the user clicks the button, open the modal 
btn.onclick = function() 
{
    modal.style.display = "block";
	model.innerHTML="Intensity Of the Light Was Set to :"+slider1.value; 
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() 
{
    modal.style.display = "none";
}
</script>
</form>




